# Fancy 3D flip card (on hover - CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Karthika-Raj/pen/GRedRPy](https://codepen.io/Karthika-Raj/pen/GRedRPy).

Fancy CSS 3D flip card that can be used for call-to-actions (CTAs)